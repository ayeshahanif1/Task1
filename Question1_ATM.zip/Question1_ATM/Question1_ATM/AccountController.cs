﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question1_ATM
{
    class AccountController
    {
        public static int genrateAccountNumber()
        {
            int accountNumber = FileHandler.readPreviousAccountNumber();

            accountNumber++;

            FileHandler.updateNewAccount(accountNumber);

            return accountNumber;
        }

        public static void deleteAccount(int accountNumber)
        {
            int count = 0;
            bool isFound = false;
            List<Account> accounts = FileHandler.readAccounts();

            foreach (Account a in accounts)
            {
                if (accountNumber == a.accountNumber)
                {
                    isFound = true;
                    break;
                }
                count++;
            } 

            if (isFound)
            {
                accounts.RemoveAt(count);
                FileHandler.resetAccountData(accounts);
                Console.WriteLine("Account Deleted..!");
                Console.ReadKey();
            }
            else {
                Console.WriteLine("Account Not Exists..!");
                Console.ReadKey();
            }
        }

        public static void updateAccount(Account account)
        {

            List<Account> accounts = FileHandler.readAccounts();
            for (int index = 0; index < accounts.Count; index++)
            {
                if (accounts.ElementAt(index).accountNumber == account.accountNumber)
                {
                    accounts.ElementAt(index).login = account.login;
                    accounts.ElementAt(index).pinCode = account.pinCode;
                    accounts.ElementAt(index).name = account.name;
                    accounts.ElementAt(index).type = account.type;
                    accounts.ElementAt(index).balance = account.balance;
                    accounts.ElementAt(index).status = account.status;

                    break;
                }
            }

            FileHandler.resetAccountData(accounts);
        }

        public static bool isAccountExist(int accountNumber)
        { 
            List<Account> accounts = FileHandler.readAccounts();

            foreach (Account a in accounts)
            {
                if (accountNumber == a.accountNumber)
                {
                   return true;
                }
            }

            return false;
        }

        public static void searchAccount(int accountNumber)
        {
            int count = 0;
            bool isFound = false;
            List<Account> accounts = FileHandler.readAccounts();

            foreach (Account a in accounts)
            {
                if (accountNumber == a.accountNumber)
                {
                    isFound = true;
                    break;
                }
                count++;
            }

            if (isFound)
            {
                Account account = accounts.ElementAt(count);

                Console.WriteLine("------------------------------------------");
                Console.WriteLine(account.accountNumber);
                Console.WriteLine(account.login);
                Console.WriteLine(account.pinCode);
                Console.WriteLine(account.name);
                Console.WriteLine(account.type);
                Console.WriteLine(account.balance);
                Console.WriteLine(account.status);
                Console.WriteLine("------------------------------------------");
                Console.ReadKey();
            }
            else
            {
                Console.WriteLine("Account Not Exists..!");
                Console.ReadKey();
            }
        }

        public static void genrateReport() {
            List<Account> accounts = FileHandler.readAccounts();

            foreach (Account account in accounts)
            {
                Console.WriteLine("------------------------------------------");
                Console.WriteLine(account.accountNumber);
                Console.WriteLine(account.login);
                Console.WriteLine(account.pinCode);
                Console.WriteLine(account.name);
                Console.WriteLine(account.type);
                Console.WriteLine(account.balance);
                Console.WriteLine(account.status);
                Console.WriteLine("------------------------------------------");
            }

            Console.ReadKey();
        }
    }
}
