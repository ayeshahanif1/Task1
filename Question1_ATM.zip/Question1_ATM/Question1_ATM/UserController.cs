﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question1_ATM
{
    class UserController
    {
        public static int accountNumber;

        public static bool isLoggedIn(int userType)
        {
            Console.WriteLine("Enter Login Name : ");
            string loginName = Console.ReadLine();

            Console.WriteLine("Enter Pin : ");
            int pinCode = Convert.ToInt32(Console.ReadLine());

            if (userType == 1)
            {
                List<Account> accounts = FileHandler.readAccounts();
                foreach (Account ac in accounts) {
                    if (ac.login.Equals(loginName) && ac.pinCode == pinCode)
                    {
                        return true;
                    }
                }
                Console.WriteLine("invalid User Credentials..!");
                return false;
            }
            else if (userType == 2)
            {
                if (loginName.Equals("admin") && pinCode == 4455)
                {
                    return true;
                }
                else
                {
                    Console.WriteLine("invalid User Credentials..!");
                    Console.ReadKey();
                    return false;
                }
            }
            else 
            {
                Console.WriteLine("invalid User Type Selected..!");
                return false;
            }
        }
    }
}
