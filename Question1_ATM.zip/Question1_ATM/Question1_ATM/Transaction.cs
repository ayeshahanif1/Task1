﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question1_ATM
{
    class Transaction
    {
        public int userId
        { get; set; }

        public string holderName
        { get; set; }

        public int amount
        { get; set; }

        public string date
        { get; set; }

        public string transactionType
        { get; set; }
    }
}
