﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Question1_ATM
{
    class Account
    {
        public int accountNumber
        { get; set; }

        public string login
        { get; set; }

        public int pinCode
        { get; set; }

        public string name
        { get; set; }

        public string type
        { get; set; }

        public int balance
        { get; set; }


        public string status
        { get; set; }
    }
}
