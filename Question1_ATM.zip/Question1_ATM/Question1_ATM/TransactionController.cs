﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question1_ATM
{
    class TransactionController
    {
        public static void withDrawAmount(int amount)
        {
            Account account = FileHandler.getAccount(UserController.accountNumber);
            if (account != null) {
                if (account.balance >= amount)
                {
                    Transaction tr = new Transaction();
                    tr.amount = amount;
                    tr.date = "";
                    tr.transactionType = "";
                    tr.userId = account.accountNumber;
                    tr.holderName = account.name;

                    account.balance = account.balance - amount;
                    AccountController.updateAccount(account);
                  
                }
                else
                {
                    Console.WriteLine("Cash  Is Low In Account !");
                }
            }
        }
    }
}
