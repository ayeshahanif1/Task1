﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Question1_ATM
{
    class Interface
    {
        public void mainMenu()
        {
            Console.WriteLine("-----Main Menu-----");
            Console.WriteLine("Enter the choice(1 for customer/ 2 for admin");

            int str=Convert.ToInt32(Console.ReadLine());

            if (!UserController.isLoggedIn(str)) {
                Console.WriteLine("Unable to process due to authorization failed...!");
                Console.ReadKey();
                return;
            }

            if(str==1)
            {

                Console.WriteLine("Enter the choice for customer to perform function:");
                Console.WriteLine("1----Withdraw Cash");
                Console.WriteLine("2----Cash  Transfer");
                Console.WriteLine("3----Deposit  Cash");
                Console.WriteLine("4----Display  Balance");
                Console.WriteLine("5----Exit");
                Console.WriteLine("Enter the choice for customer menu: ");
                int ch=Convert.ToInt32(Console.ReadLine());
                switch(ch)
                {
                    case 1:
                        {
                            Console.WriteLine("please select a mode for withdraw:(!for fast cash/2 for normal cash");
                            int choice = Convert.ToInt32(Console.ReadLine());
                            if (choice == 1)
                            {
                                Console.WriteLine("Select one of the dominations of money: ");
                                Console.WriteLine("1----500");
                                Console.WriteLine("2----1000");
                                Console.WriteLine("3----2000");
                                Console.WriteLine("4----5000");
                                Console.WriteLine("5----10000");
                                Console.WriteLine("6----15000");
                                Console.WriteLine("7----20000");
                                Console.WriteLine("Are you sure you want to withdraw that money?(Y/N): (1 for Y/ 2 for N)");
                                int c = Convert.ToInt32(Console.ReadLine());

                                TransactionController.withDrawAmount(c);
                              //  Console.WriteLine("Cash  Successfully Withdrawn!");
                                Console.WriteLine("Do  you wish to print a receipt (Y/N)? (1 for Y / 2 for N)");

                            }
                            else if (choice == 2)
                            {
                                Console.WriteLine("Enter  the withdrawal amount:");
                                int wd = Convert.ToInt32(Console.ReadLine());
                                TransactionController.withDrawAmount(wd);
                               // Console.WriteLine("Cash  Successfully Withdrawn!");
                                Console.WriteLine("Do  you wish to print a receipt (Y/N)? (1 for Y / 2 for N)");
                            }
                            else
                            {
                                Console.WriteLine("invalid");
                            }
                        }
                        break;
                    case 2:
                        {
                             Console.WriteLine("Enter  amount in multiples of 500 for transfing: ");
                             int ta = Convert.ToInt32(Console.ReadLine());
                             Console.WriteLine("Transaction confirmed");
                             Console.WriteLine("Do  you wish to print a receipt (Y/N)? (1 for Y / 2 for N)");
                             break;
                        }
                    case 3:
                        {
                             Console.WriteLine("Enter the cash amount to deposit:");
                             int d = Convert.ToInt32(Console.ReadLine());
                             Console.WriteLine("Cash  Deposited Successfully.");
                             Console.WriteLine("Do  you wish to print a receipt (Y/N)? (1 for Y / 2 for N)");
                             break;
                        }
                    case 4:
                         {
                             Console.WriteLine("Display balance");
                             break;
                         }
                    default:
                         {
                             Console.WriteLine("invalid");
                             break;
                         }
               }

            }
            else if(str==2)
            {
                Console.WriteLine("Enter the choice for admin to perform function:");
                Console.WriteLine("1----Create  New Account");
                Console.WriteLine("2----Delete  Existing Account");
                Console.WriteLine("3----Update  Account Information");
                Console.WriteLine("4----Search  for Account");
                Console.WriteLine("5----View  Reports");
                Console.WriteLine("6----Exit");
                int temp=Convert.ToInt32(Console.ReadLine());
                
                if(temp==1)
                {
                    Account account = new Account();

                    Console.WriteLine("Enter login:");
                    account.login = Console.ReadLine();
                    Console.WriteLine("Enter pin code:");
                    account.pinCode = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Holders name:");
                    account.name = Console.ReadLine();
                    Console.WriteLine("Enter type(saving/ current:");
                    account.type = Console.ReadLine();
                    Console.WriteLine("Enter starting balnace:");
                    account.balance = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter the status(active/disabled):");
                    account.status = Console.ReadLine();

                    account.accountNumber = AccountController.genrateAccountNumber();

                    FileHandler.writeAccountData(account);

                    Console.WriteLine("Account Registered...!");
                    Console.WriteLine("And Account number is " +account.accountNumber);
                    Console.ReadKey();
                }
                else if(temp==2)
                {
                    Console.WriteLine("Enter  the account number to which you want to delete:");
                    int account_number = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Again Enter  the account number to which you want to delete:");
                    account_number = Convert.ToInt32(Console.ReadLine());

                    AccountController.deleteAccount(account_number);

                }
                else if(temp==3)
                {
                    Console.WriteLine("Enter  the Account Number for update");
                    int update_account_number = Convert.ToInt32(Console.ReadLine());

                    if (AccountController.isAccountExist(update_account_number))
                    {
                        Account account = new Account();

                        Console.WriteLine("Enter login:");
                        account.login = Console.ReadLine();
                        Console.WriteLine("Enter pin code:");
                        account.pinCode = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter Holders name:");
                        account.name = Console.ReadLine();
                        Console.WriteLine("Enter type(saving/ current:");
                        account.type = Console.ReadLine();
                        Console.WriteLine("Enter starting balnace:");
                        account.balance = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter the status:");
                        account.status = Console.ReadLine();

                        account.accountNumber = update_account_number;

                        AccountController.updateAccount(account);

                        Console.WriteLine("Account Updated...!");
                        Console.ReadKey();
                    }
                }
                else if(temp==4)
                {
                    Console.WriteLine("Searching an account");
                    int search_account_number = Convert.ToInt32(Console.ReadLine());
                    AccountController.searchAccount(search_account_number);

                }
                else if(temp==5)
                {
                    Console.WriteLine("view report");
                    AccountController.genrateReport();
                }
                else
                {
                    Console.WriteLine("invalid");
                }
            }
            else
            {
                Console.WriteLine("invalid");
            }
           
        }
    }
}
