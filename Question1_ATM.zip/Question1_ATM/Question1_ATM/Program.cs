﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question1_ATM
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Account> accounts = FileHandler.readAccounts();

            foreach (Account account in accounts)
            {
                Console.WriteLine(account.accountNumber);
                Console.WriteLine(account.login);
                Console.WriteLine(account.pinCode);
                Console.WriteLine(account.name);
                Console.WriteLine(account.type);
                Console.WriteLine(account.balance);
                Console.WriteLine(account.status);
                Console.WriteLine("------------------------------------------");
            }

            Interface menu = new Interface();
            menu.mainMenu();
        }
    }
}
