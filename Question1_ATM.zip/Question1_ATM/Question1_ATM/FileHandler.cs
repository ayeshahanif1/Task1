﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question1_ATM
{
    class FileHandler
    {
        private static FileStream fs;

        private static string fileNameAccounts = "fileNameAccounts";
        private static string fileNameAccountNumber = "fileNameAccountNumber";

        public static void writeAccountData(Account account){
            //writeToBinaryFile

            List<Account> previousAccounts = readAccounts();
            previousAccounts.Add(account);

           BinaryWriter bw;

            try
            {
               bw = new BinaryWriter(new FileStream(fileNameAccounts, FileMode.Create));
            }
            catch (IOException e)
            {
                Console.WriteLine(e.Message + "\n Cannot create file.");
                return;
            }

            //writing into the file
            try
            {
                foreach (Account tempAccount in previousAccounts) {
                    bw.Write(tempAccount.accountNumber);
                    bw.Write(tempAccount.login);
                    bw.Write(tempAccount.pinCode);
                    bw.Write(tempAccount.name);
                    bw.Write(tempAccount.type);
                    bw.Write(tempAccount.balance);
                    bw.Write(tempAccount.status);
                }

            }
            catch (IOException e)
            {
                Console.WriteLine(e.Message + "\n Cannot write to file.");
                return;
            }
            bw.Close();
        }

        public static void resetAccountData(List<Account> accounts)
        {
    
            BinaryWriter bw;

            try
            {
                bw = new BinaryWriter(new FileStream(fileNameAccounts, FileMode.Create));
            }
            catch (IOException e)
            {
                Console.WriteLine(e.Message + "\n Cannot create file.");
                return;
            }

            //writing into the file
            try
            {
                foreach (Account tempAccount in accounts)
                {
                    bw.Write(tempAccount.accountNumber);
                    bw.Write(tempAccount.login);
                    bw.Write(tempAccount.pinCode);
                    bw.Write(tempAccount.name);
                    bw.Write(tempAccount.type);
                    bw.Write(tempAccount.balance);
                    bw.Write(tempAccount.status);
                }

            }
            catch (IOException e)
            {
                Console.WriteLine(e.Message + "\n Cannot write to file.");
                return;
            }
            bw.Close();
        }

        public static Account getAccount(int accountNumber)
        {

            BinaryReader br;

            //reading from the file
            try
            {
                fs = new FileStream(fileNameAccounts, FileMode.Open);
                br = new BinaryReader(fs);
            }
            catch (IOException e)
            {
                Console.WriteLine(e.Message + "\n Cannot open file.");
                return null;
            }

            try
            {
                while (fs.Position != fs.Length)
                {
                    Account ac = new Account();

                    ac.accountNumber = br.ReadInt32();
                    ac.login = br.ReadString();
                    ac.pinCode = br.ReadInt32();
                    ac.name = br.ReadString();
                    ac.type = br.ReadString();
                    ac.balance = br.ReadInt32();
                    ac.status = br.ReadString();

                    if (ac.accountNumber == accountNumber)
                    {
                        br.Close();
                        return ac;
                    }
                }

            }
            catch (IOException e)
            {
                Console.WriteLine(e.Message + "\n Cannot read from file.");
                return null;
            }
            br.Close();

            return null;      
        }

        public static List<Account> readAccounts(){ 

            List<Account> accounts = new List<Account>();

            BinaryReader br;

            //reading from the file
            try
            {
                fs = new FileStream(fileNameAccounts, FileMode.Open);
                br = new BinaryReader(fs);
            }
            catch (IOException e)
            {
                Console.WriteLine(e.Message + "\n Cannot open file.");
                return accounts;
            }

            try
            {
                while (fs.Position != fs.Length)
                {
                    Account account = new Account();

                    account.accountNumber = br.ReadInt32();
                    account.login = br.ReadString();
                    account.pinCode = br.ReadInt32();
                    account.name = br.ReadString();
                    account.type = br.ReadString();
                    account.balance = br.ReadInt32();
                    account.status = br.ReadString();

                    accounts.Add(account);
                }

            }
            catch (IOException e)
            {
                Console.WriteLine(e.Message + "\n Cannot read from file.");
                return accounts;
            }
            br.Close();

            return accounts;
        }

        public static int readPreviousAccountNumber()
        {

            int previous = 0;

            BinaryReader br;

            //reading from the file
            try
            {
                fs = new FileStream(fileNameAccountNumber, FileMode.Open);
                br = new BinaryReader(fs);
            }
            catch (IOException e)
            {
                //Console.WriteLine(e.Message + "\n Cannot open file.");
                return previous;
            }

            try
            {
                previous = br.ReadInt32();
            }
            catch (IOException e)
            {
                //Console.WriteLine(e.Message + "\n Cannot read from file.");
                return previous;
            }
            br.Close();

            return previous;
        }

        public static void updateNewAccount(int accountNumber)
        {
            BinaryWriter bw;

            try
            {
                bw = new BinaryWriter(new FileStream(fileNameAccountNumber, FileMode.Create));
            }
            catch (IOException e)
            {
                Console.WriteLine(e.Message + "\n Cannot create file.");
                return;
            }

            //writing into the file
            try
            {
                bw.Write(accountNumber);
            }
            catch (IOException e)
            {
                Console.WriteLine(e.Message + "\n Cannot write to file.");
                return;
            }
            bw.Close();
        }
    }

}
